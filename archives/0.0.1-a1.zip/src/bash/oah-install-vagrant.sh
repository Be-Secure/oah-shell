#!/bin/bash
function __oah_install_vagrant() {

  git clone https://github.com/jobyko/oah-bes-vm.git /c/Users/jo329373/.oah/data/.envs/
  cd /c/Users/jo329373/.oah/data/.envs/oah-bes-vm/host/vagrant
  vagrant up
  vagrant ssh
  ansible-playbook /home/vagrant/oah-bes-vm/provisioning/oah-install.yml

}

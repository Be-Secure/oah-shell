#!/bin/bash
function __oah_install_vagrant() {

  git clone https://github.com/jobyko/oah-bes-vm.git
  cd /c/Users/jo329373/Desktop/Be-Secure/oah-bes-vm/host/vagrant
  vagrant up  
  #vagrant ssh -c "ansible-playbook /home/vagrant/oah-bes-vm/provisioning/oah-install.yml"
  #ansible-playbook /home/vagrant/oah-bes-vm/provisioning/oah-install.yml

}
